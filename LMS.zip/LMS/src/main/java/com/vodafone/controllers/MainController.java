package com.vodafone.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.vodafone.model.Book;
import com.vodafone.services.BookService;

@Controller
public class MainController {
	
	
	@Autowired
	private BookService service ;
	
	
	@GetMapping("/")

	public String  init(HttpServletRequest req) {
		req.setAttribute("books", service.findAllBooks());
return "index";
}


}
