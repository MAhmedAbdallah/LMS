package com.vodafone.controllers;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.vodafone.model.Book;
import com.vodafone.services.BookService;

@RestController

public class LibraryController {
	@Autowired
	private BookService service;

	@RequestMapping("test")
	@ResponseBody
	public String getTestMessage() {
		return "This is the Message" ;
	}
	@GetMapping("/findAllBooks")
	//@ResponseBody
	public List<Book> getAllBooks()
	{	System.out.println("Heeeeeeeeeeeereeeeeeeeeeeeeeeee");
		return (List<Book>) service.findAllBooks();
	}

	@GetMapping("/delete")
	public void deleteBook(@RequestParam(name="id") int bookId) {
		service.deleteBook(bookId);
	}
	
	
}
