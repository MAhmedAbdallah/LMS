package com.vodafone.services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vodafone.DAO.BookRepository;
import com.vodafone.model.Book;


@Service
public class BookService {

	
	 public BookService() {
		this(5);
	}
	 public BookService(int x) {
		System.out.println("hello"+x);
	}
	
	
	@Autowired
	private BookRepository repo ;
	
	
	public Collection<Book> findAllBooks(){
		List<Book> bookList = new ArrayList<Book>();
		for(Book b : repo.findAll()) {
			bookList.add(b);
			System.out.println(b.getBookName());
		}
		return bookList;
	}
	public void deleteBook(int BookId) {
		repo.deleteById(BookId);
		
	}
}
